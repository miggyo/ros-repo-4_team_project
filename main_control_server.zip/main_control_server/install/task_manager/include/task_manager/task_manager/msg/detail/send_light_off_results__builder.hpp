// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from task_manager:msg/SendLightOffResults.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_OFF_RESULTS__BUILDER_HPP_
#define TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_OFF_RESULTS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "task_manager/msg/detail/send_light_off_results__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace task_manager
{

namespace msg
{

namespace builder
{

class Init_SendLightOffResults_task_complete
{
public:
  explicit Init_SendLightOffResults_task_complete(::task_manager::msg::SendLightOffResults & msg)
  : msg_(msg)
  {}
  ::task_manager::msg::SendLightOffResults task_complete(::task_manager::msg::SendLightOffResults::_task_complete_type arg)
  {
    msg_.task_complete = std::move(arg);
    return std::move(msg_);
  }

private:
  ::task_manager::msg::SendLightOffResults msg_;
};

class Init_SendLightOffResults_current_rack
{
public:
  Init_SendLightOffResults_current_rack()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SendLightOffResults_task_complete current_rack(::task_manager::msg::SendLightOffResults::_current_rack_type arg)
  {
    msg_.current_rack = std::move(arg);
    return Init_SendLightOffResults_task_complete(msg_);
  }

private:
  ::task_manager::msg::SendLightOffResults msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::task_manager::msg::SendLightOffResults>()
{
  return task_manager::msg::builder::Init_SendLightOffResults_current_rack();
}

}  // namespace task_manager

#endif  // TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_OFF_RESULTS__BUILDER_HPP_
