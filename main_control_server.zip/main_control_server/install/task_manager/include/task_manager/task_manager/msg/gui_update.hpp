// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__GUI_UPDATE_HPP_
#define TASK_MANAGER__MSG__GUI_UPDATE_HPP_

#include "task_manager/msg/detail/gui_update__struct.hpp"
#include "task_manager/msg/detail/gui_update__builder.hpp"
#include "task_manager/msg/detail/gui_update__traits.hpp"

#endif  // TASK_MANAGER__MSG__GUI_UPDATE_HPP_
