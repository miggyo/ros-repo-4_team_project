// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from task_manager:msg/SendLightOffResults.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_OFF_RESULTS__STRUCT_H_
#define TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_OFF_RESULTS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'current_rack'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/SendLightOffResults in the package task_manager.
typedef struct task_manager__msg__SendLightOffResults
{
  rosidl_runtime_c__String current_rack;
  bool task_complete;
} task_manager__msg__SendLightOffResults;

// Struct for a sequence of task_manager__msg__SendLightOffResults.
typedef struct task_manager__msg__SendLightOffResults__Sequence
{
  task_manager__msg__SendLightOffResults * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} task_manager__msg__SendLightOffResults__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_OFF_RESULTS__STRUCT_H_
