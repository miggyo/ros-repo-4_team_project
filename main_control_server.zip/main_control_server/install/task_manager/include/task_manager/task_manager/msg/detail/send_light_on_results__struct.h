// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from task_manager:msg/SendLightOnResults.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__STRUCT_H_
#define TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'current_rack'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/SendLightOnResults in the package task_manager.
typedef struct task_manager__msg__SendLightOnResults
{
  /// 'R_A1'
  rosidl_runtime_c__String current_rack;
  /// True
  bool complete;
} task_manager__msg__SendLightOnResults;

// Struct for a sequence of task_manager__msg__SendLightOnResults.
typedef struct task_manager__msg__SendLightOnResults__Sequence
{
  task_manager__msg__SendLightOnResults * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} task_manager__msg__SendLightOnResults__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__STRUCT_H_
