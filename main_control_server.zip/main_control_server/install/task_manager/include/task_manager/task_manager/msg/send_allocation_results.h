// generated from rosidl_generator_c/resource/idl.h.em
// with input from task_manager:msg/SendAllocationResults.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__SEND_ALLOCATION_RESULTS_H_
#define TASK_MANAGER__MSG__SEND_ALLOCATION_RESULTS_H_

#include "task_manager/msg/detail/send_allocation_results__struct.h"
#include "task_manager/msg/detail/send_allocation_results__functions.h"
#include "task_manager/msg/detail/send_allocation_results__type_support.h"

#endif  // TASK_MANAGER__MSG__SEND_ALLOCATION_RESULTS_H_
