// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__SEND_LIGHT_OFF_RESULTS_HPP_
#define TASK_MANAGER__MSG__SEND_LIGHT_OFF_RESULTS_HPP_

#include "task_manager/msg/detail/send_light_off_results__struct.hpp"
#include "task_manager/msg/detail/send_light_off_results__builder.hpp"
#include "task_manager/msg/detail/send_light_off_results__traits.hpp"

#endif  // TASK_MANAGER__MSG__SEND_LIGHT_OFF_RESULTS_HPP_
