// generated from rosidl_generator_c/resource/idl.h.em
// with input from task_manager:msg/StartInspection.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__START_INSPECTION_H_
#define TASK_MANAGER__MSG__START_INSPECTION_H_

#include "task_manager/msg/detail/start_inspection__struct.h"
#include "task_manager/msg/detail/start_inspection__functions.h"
#include "task_manager/msg/detail/start_inspection__type_support.h"

#endif  // TASK_MANAGER__MSG__START_INSPECTION_H_
