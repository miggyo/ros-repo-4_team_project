// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__INSPECTION_COMPLETE_HPP_
#define TASK_MANAGER__MSG__INSPECTION_COMPLETE_HPP_

#include "task_manager/msg/detail/inspection_complete__struct.hpp"
#include "task_manager/msg/detail/inspection_complete__builder.hpp"
#include "task_manager/msg/detail/inspection_complete__traits.hpp"

#endif  // TASK_MANAGER__MSG__INSPECTION_COMPLETE_HPP_
