// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from task_manager:msg/SendLightOnResults.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__STRUCT_HPP_
#define TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__task_manager__msg__SendLightOnResults __attribute__((deprecated))
#else
# define DEPRECATED__task_manager__msg__SendLightOnResults __declspec(deprecated)
#endif

namespace task_manager
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SendLightOnResults_
{
  using Type = SendLightOnResults_<ContainerAllocator>;

  explicit SendLightOnResults_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->current_rack = "";
      this->complete = false;
    }
  }

  explicit SendLightOnResults_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : current_rack(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->current_rack = "";
      this->complete = false;
    }
  }

  // field types and members
  using _current_rack_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _current_rack_type current_rack;
  using _complete_type =
    bool;
  _complete_type complete;

  // setters for named parameter idiom
  Type & set__current_rack(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->current_rack = _arg;
    return *this;
  }
  Type & set__complete(
    const bool & _arg)
  {
    this->complete = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    task_manager::msg::SendLightOnResults_<ContainerAllocator> *;
  using ConstRawPtr =
    const task_manager::msg::SendLightOnResults_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<task_manager::msg::SendLightOnResults_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<task_manager::msg::SendLightOnResults_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      task_manager::msg::SendLightOnResults_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<task_manager::msg::SendLightOnResults_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      task_manager::msg::SendLightOnResults_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<task_manager::msg::SendLightOnResults_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<task_manager::msg::SendLightOnResults_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<task_manager::msg::SendLightOnResults_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__task_manager__msg__SendLightOnResults
    std::shared_ptr<task_manager::msg::SendLightOnResults_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__task_manager__msg__SendLightOnResults
    std::shared_ptr<task_manager::msg::SendLightOnResults_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SendLightOnResults_ & other) const
  {
    if (this->current_rack != other.current_rack) {
      return false;
    }
    if (this->complete != other.complete) {
      return false;
    }
    return true;
  }
  bool operator!=(const SendLightOnResults_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SendLightOnResults_

// alias to use template instance with default allocator
using SendLightOnResults =
  task_manager::msg::SendLightOnResults_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace task_manager

#endif  // TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__STRUCT_HPP_
