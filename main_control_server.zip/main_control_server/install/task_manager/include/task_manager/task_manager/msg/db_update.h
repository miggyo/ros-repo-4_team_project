// generated from rosidl_generator_c/resource/idl.h.em
// with input from task_manager:msg/DbUpdate.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__DB_UPDATE_H_
#define TASK_MANAGER__MSG__DB_UPDATE_H_

#include "task_manager/msg/detail/db_update__struct.h"
#include "task_manager/msg/detail/db_update__functions.h"
#include "task_manager/msg/detail/db_update__type_support.h"

#endif  // TASK_MANAGER__MSG__DB_UPDATE_H_
