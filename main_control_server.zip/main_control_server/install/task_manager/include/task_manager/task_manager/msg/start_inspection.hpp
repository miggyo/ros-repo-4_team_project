// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__START_INSPECTION_HPP_
#define TASK_MANAGER__MSG__START_INSPECTION_HPP_

#include "task_manager/msg/detail/start_inspection__struct.hpp"
#include "task_manager/msg/detail/start_inspection__builder.hpp"
#include "task_manager/msg/detail/start_inspection__traits.hpp"

#endif  // TASK_MANAGER__MSG__START_INSPECTION_HPP_
