// generated from rosidl_generator_c/resource/idl.h.em
// with input from task_manager:msg/SendLightOnResults.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__SEND_LIGHT_ON_RESULTS_H_
#define TASK_MANAGER__MSG__SEND_LIGHT_ON_RESULTS_H_

#include "task_manager/msg/detail/send_light_on_results__struct.h"
#include "task_manager/msg/detail/send_light_on_results__functions.h"
#include "task_manager/msg/detail/send_light_on_results__type_support.h"

#endif  // TASK_MANAGER__MSG__SEND_LIGHT_ON_RESULTS_H_
