// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from task_manager:msg/SendLightOnResults.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__BUILDER_HPP_
#define TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "task_manager/msg/detail/send_light_on_results__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace task_manager
{

namespace msg
{

namespace builder
{

class Init_SendLightOnResults_complete
{
public:
  explicit Init_SendLightOnResults_complete(::task_manager::msg::SendLightOnResults & msg)
  : msg_(msg)
  {}
  ::task_manager::msg::SendLightOnResults complete(::task_manager::msg::SendLightOnResults::_complete_type arg)
  {
    msg_.complete = std::move(arg);
    return std::move(msg_);
  }

private:
  ::task_manager::msg::SendLightOnResults msg_;
};

class Init_SendLightOnResults_current_rack
{
public:
  Init_SendLightOnResults_current_rack()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SendLightOnResults_complete current_rack(::task_manager::msg::SendLightOnResults::_current_rack_type arg)
  {
    msg_.current_rack = std::move(arg);
    return Init_SendLightOnResults_complete(msg_);
  }

private:
  ::task_manager::msg::SendLightOnResults msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::task_manager::msg::SendLightOnResults>()
{
  return task_manager::msg::builder::Init_SendLightOnResults_current_rack();
}

}  // namespace task_manager

#endif  // TASK_MANAGER__MSG__DETAIL__SEND_LIGHT_ON_RESULTS__BUILDER_HPP_
