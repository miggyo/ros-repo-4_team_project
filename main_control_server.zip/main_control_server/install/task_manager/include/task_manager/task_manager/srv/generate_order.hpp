// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__SRV__GENERATE_ORDER_HPP_
#define TASK_MANAGER__SRV__GENERATE_ORDER_HPP_

#include "task_manager/srv/detail/generate_order__struct.hpp"
#include "task_manager/srv/detail/generate_order__builder.hpp"
#include "task_manager/srv/detail/generate_order__traits.hpp"

#endif  // TASK_MANAGER__SRV__GENERATE_ORDER_HPP_
