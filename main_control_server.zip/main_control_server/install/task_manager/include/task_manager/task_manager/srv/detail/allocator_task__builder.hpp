// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from task_manager:srv/AllocatorTask.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__BUILDER_HPP_
#define TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "task_manager/srv/detail/allocator_task__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace task_manager
{

namespace srv
{

namespace builder
{

class Init_AllocatorTask_Request_estimated_completion_time
{
public:
  explicit Init_AllocatorTask_Request_estimated_completion_time(::task_manager::srv::AllocatorTask_Request & msg)
  : msg_(msg)
  {}
  ::task_manager::srv::AllocatorTask_Request estimated_completion_time(::task_manager::srv::AllocatorTask_Request::_estimated_completion_time_type arg)
  {
    msg_.estimated_completion_time = std::move(arg);
    return std::move(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Request msg_;
};

class Init_AllocatorTask_Request_status
{
public:
  explicit Init_AllocatorTask_Request_status(::task_manager::srv::AllocatorTask_Request & msg)
  : msg_(msg)
  {}
  Init_AllocatorTask_Request_estimated_completion_time status(::task_manager::srv::AllocatorTask_Request::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_AllocatorTask_Request_estimated_completion_time(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Request msg_;
};

class Init_AllocatorTask_Request_battery_status
{
public:
  explicit Init_AllocatorTask_Request_battery_status(::task_manager::srv::AllocatorTask_Request & msg)
  : msg_(msg)
  {}
  Init_AllocatorTask_Request_status battery_status(::task_manager::srv::AllocatorTask_Request::_battery_status_type arg)
  {
    msg_.battery_status = std::move(arg);
    return Init_AllocatorTask_Request_status(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Request msg_;
};

class Init_AllocatorTask_Request_robot_name
{
public:
  explicit Init_AllocatorTask_Request_robot_name(::task_manager::srv::AllocatorTask_Request & msg)
  : msg_(msg)
  {}
  Init_AllocatorTask_Request_battery_status robot_name(::task_manager::srv::AllocatorTask_Request::_robot_name_type arg)
  {
    msg_.robot_name = std::move(arg);
    return Init_AllocatorTask_Request_battery_status(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Request msg_;
};

class Init_AllocatorTask_Request_task_type
{
public:
  explicit Init_AllocatorTask_Request_task_type(::task_manager::srv::AllocatorTask_Request & msg)
  : msg_(msg)
  {}
  Init_AllocatorTask_Request_robot_name task_type(::task_manager::srv::AllocatorTask_Request::_task_type_type arg)
  {
    msg_.task_type = std::move(arg);
    return Init_AllocatorTask_Request_robot_name(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Request msg_;
};

class Init_AllocatorTask_Request_product_code_list
{
public:
  explicit Init_AllocatorTask_Request_product_code_list(::task_manager::srv::AllocatorTask_Request & msg)
  : msg_(msg)
  {}
  Init_AllocatorTask_Request_task_type product_code_list(::task_manager::srv::AllocatorTask_Request::_product_code_list_type arg)
  {
    msg_.product_code_list = std::move(arg);
    return Init_AllocatorTask_Request_task_type(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Request msg_;
};

class Init_AllocatorTask_Request_task_code
{
public:
  Init_AllocatorTask_Request_task_code()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AllocatorTask_Request_product_code_list task_code(::task_manager::srv::AllocatorTask_Request::_task_code_type arg)
  {
    msg_.task_code = std::move(arg);
    return Init_AllocatorTask_Request_product_code_list(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::task_manager::srv::AllocatorTask_Request>()
{
  return task_manager::srv::builder::Init_AllocatorTask_Request_task_code();
}

}  // namespace task_manager


namespace task_manager
{

namespace srv
{

namespace builder
{

class Init_AllocatorTask_Response_task_assignment
{
public:
  explicit Init_AllocatorTask_Response_task_assignment(::task_manager::srv::AllocatorTask_Response & msg)
  : msg_(msg)
  {}
  ::task_manager::srv::AllocatorTask_Response task_assignment(::task_manager::srv::AllocatorTask_Response::_task_assignment_type arg)
  {
    msg_.task_assignment = std::move(arg);
    return std::move(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Response msg_;
};

class Init_AllocatorTask_Response_rack_list
{
public:
  explicit Init_AllocatorTask_Response_rack_list(::task_manager::srv::AllocatorTask_Response & msg)
  : msg_(msg)
  {}
  Init_AllocatorTask_Response_task_assignment rack_list(::task_manager::srv::AllocatorTask_Response::_rack_list_type arg)
  {
    msg_.rack_list = std::move(arg);
    return Init_AllocatorTask_Response_task_assignment(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Response msg_;
};

class Init_AllocatorTask_Response_task_code
{
public:
  explicit Init_AllocatorTask_Response_task_code(::task_manager::srv::AllocatorTask_Response & msg)
  : msg_(msg)
  {}
  Init_AllocatorTask_Response_rack_list task_code(::task_manager::srv::AllocatorTask_Response::_task_code_type arg)
  {
    msg_.task_code = std::move(arg);
    return Init_AllocatorTask_Response_rack_list(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Response msg_;
};

class Init_AllocatorTask_Response_robot_name
{
public:
  Init_AllocatorTask_Response_robot_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AllocatorTask_Response_task_code robot_name(::task_manager::srv::AllocatorTask_Response::_robot_name_type arg)
  {
    msg_.robot_name = std::move(arg);
    return Init_AllocatorTask_Response_task_code(msg_);
  }

private:
  ::task_manager::srv::AllocatorTask_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::task_manager::srv::AllocatorTask_Response>()
{
  return task_manager::srv::builder::Init_AllocatorTask_Response_robot_name();
}

}  // namespace task_manager

#endif  // TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__BUILDER_HPP_
