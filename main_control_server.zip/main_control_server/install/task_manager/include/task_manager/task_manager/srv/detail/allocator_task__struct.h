// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from task_manager:srv/AllocatorTask.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__STRUCT_H_
#define TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'task_code'
// Member 'product_code_list'
// Member 'task_type'
// Member 'robot_name'
// Member 'battery_status'
// Member 'status'
// Member 'estimated_completion_time'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/AllocatorTask in the package task_manager.
typedef struct task_manager__srv__AllocatorTask_Request
{
  rosidl_runtime_c__String task_code;
  /// ['P02', 'P01', 'P03']
  rosidl_runtime_c__String__Sequence product_code_list;
  rosidl_runtime_c__String task_type;
  rosidl_runtime_c__String__Sequence robot_name;
  rosidl_runtime_c__String__Sequence battery_status;
  rosidl_runtime_c__String__Sequence status;
  rosidl_runtime_c__String__Sequence estimated_completion_time;
} task_manager__srv__AllocatorTask_Request;

// Struct for a sequence of task_manager__srv__AllocatorTask_Request.
typedef struct task_manager__srv__AllocatorTask_Request__Sequence
{
  task_manager__srv__AllocatorTask_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} task_manager__srv__AllocatorTask_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'robot_name'
// Member 'task_code'
// Member 'rack_list'
// Member 'task_assignment'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/AllocatorTask in the package task_manager.
typedef struct task_manager__srv__AllocatorTask_Response
{
  rosidl_runtime_c__String robot_name;
  rosidl_runtime_c__String task_code;
  rosidl_runtime_c__String__Sequence rack_list;
  rosidl_runtime_c__String task_assignment;
} task_manager__srv__AllocatorTask_Response;

// Struct for a sequence of task_manager__srv__AllocatorTask_Response.
typedef struct task_manager__srv__AllocatorTask_Response__Sequence
{
  task_manager__srv__AllocatorTask_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} task_manager__srv__AllocatorTask_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__STRUCT_H_
