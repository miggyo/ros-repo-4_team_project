// generated from rosidl_generator_c/resource/idl.h.em
// with input from task_manager:srv/GenerateOrder.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__SRV__GENERATE_ORDER_H_
#define TASK_MANAGER__SRV__GENERATE_ORDER_H_

#include "task_manager/srv/detail/generate_order__struct.h"
#include "task_manager/srv/detail/generate_order__functions.h"
#include "task_manager/srv/detail/generate_order__type_support.h"

#endif  // TASK_MANAGER__SRV__GENERATE_ORDER_H_
