// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from task_manager:srv/AllocatorTask.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__TRAITS_HPP_
#define TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "task_manager/srv/detail/allocator_task__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace task_manager
{

namespace srv
{

inline void to_flow_style_yaml(
  const AllocatorTask_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: task_code
  {
    out << "task_code: ";
    rosidl_generator_traits::value_to_yaml(msg.task_code, out);
    out << ", ";
  }

  // member: product_code_list
  {
    if (msg.product_code_list.size() == 0) {
      out << "product_code_list: []";
    } else {
      out << "product_code_list: [";
      size_t pending_items = msg.product_code_list.size();
      for (auto item : msg.product_code_list) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: task_type
  {
    out << "task_type: ";
    rosidl_generator_traits::value_to_yaml(msg.task_type, out);
    out << ", ";
  }

  // member: robot_name
  {
    if (msg.robot_name.size() == 0) {
      out << "robot_name: []";
    } else {
      out << "robot_name: [";
      size_t pending_items = msg.robot_name.size();
      for (auto item : msg.robot_name) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: battery_status
  {
    if (msg.battery_status.size() == 0) {
      out << "battery_status: []";
    } else {
      out << "battery_status: [";
      size_t pending_items = msg.battery_status.size();
      for (auto item : msg.battery_status) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: status
  {
    if (msg.status.size() == 0) {
      out << "status: []";
    } else {
      out << "status: [";
      size_t pending_items = msg.status.size();
      for (auto item : msg.status) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: estimated_completion_time
  {
    if (msg.estimated_completion_time.size() == 0) {
      out << "estimated_completion_time: []";
    } else {
      out << "estimated_completion_time: [";
      size_t pending_items = msg.estimated_completion_time.size();
      for (auto item : msg.estimated_completion_time) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AllocatorTask_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: task_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "task_code: ";
    rosidl_generator_traits::value_to_yaml(msg.task_code, out);
    out << "\n";
  }

  // member: product_code_list
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.product_code_list.size() == 0) {
      out << "product_code_list: []\n";
    } else {
      out << "product_code_list:\n";
      for (auto item : msg.product_code_list) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: task_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "task_type: ";
    rosidl_generator_traits::value_to_yaml(msg.task_type, out);
    out << "\n";
  }

  // member: robot_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.robot_name.size() == 0) {
      out << "robot_name: []\n";
    } else {
      out << "robot_name:\n";
      for (auto item : msg.robot_name) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: battery_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.battery_status.size() == 0) {
      out << "battery_status: []\n";
    } else {
      out << "battery_status:\n";
      for (auto item : msg.battery_status) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.status.size() == 0) {
      out << "status: []\n";
    } else {
      out << "status:\n";
      for (auto item : msg.status) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: estimated_completion_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.estimated_completion_time.size() == 0) {
      out << "estimated_completion_time: []\n";
    } else {
      out << "estimated_completion_time:\n";
      for (auto item : msg.estimated_completion_time) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AllocatorTask_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace task_manager

namespace rosidl_generator_traits
{

[[deprecated("use task_manager::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const task_manager::srv::AllocatorTask_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  task_manager::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use task_manager::srv::to_yaml() instead")]]
inline std::string to_yaml(const task_manager::srv::AllocatorTask_Request & msg)
{
  return task_manager::srv::to_yaml(msg);
}

template<>
inline const char * data_type<task_manager::srv::AllocatorTask_Request>()
{
  return "task_manager::srv::AllocatorTask_Request";
}

template<>
inline const char * name<task_manager::srv::AllocatorTask_Request>()
{
  return "task_manager/srv/AllocatorTask_Request";
}

template<>
struct has_fixed_size<task_manager::srv::AllocatorTask_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<task_manager::srv::AllocatorTask_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<task_manager::srv::AllocatorTask_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace task_manager
{

namespace srv
{

inline void to_flow_style_yaml(
  const AllocatorTask_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: robot_name
  {
    out << "robot_name: ";
    rosidl_generator_traits::value_to_yaml(msg.robot_name, out);
    out << ", ";
  }

  // member: task_code
  {
    out << "task_code: ";
    rosidl_generator_traits::value_to_yaml(msg.task_code, out);
    out << ", ";
  }

  // member: rack_list
  {
    if (msg.rack_list.size() == 0) {
      out << "rack_list: []";
    } else {
      out << "rack_list: [";
      size_t pending_items = msg.rack_list.size();
      for (auto item : msg.rack_list) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: task_assignment
  {
    out << "task_assignment: ";
    rosidl_generator_traits::value_to_yaml(msg.task_assignment, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AllocatorTask_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: robot_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "robot_name: ";
    rosidl_generator_traits::value_to_yaml(msg.robot_name, out);
    out << "\n";
  }

  // member: task_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "task_code: ";
    rosidl_generator_traits::value_to_yaml(msg.task_code, out);
    out << "\n";
  }

  // member: rack_list
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.rack_list.size() == 0) {
      out << "rack_list: []\n";
    } else {
      out << "rack_list:\n";
      for (auto item : msg.rack_list) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: task_assignment
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "task_assignment: ";
    rosidl_generator_traits::value_to_yaml(msg.task_assignment, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AllocatorTask_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace task_manager

namespace rosidl_generator_traits
{

[[deprecated("use task_manager::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const task_manager::srv::AllocatorTask_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  task_manager::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use task_manager::srv::to_yaml() instead")]]
inline std::string to_yaml(const task_manager::srv::AllocatorTask_Response & msg)
{
  return task_manager::srv::to_yaml(msg);
}

template<>
inline const char * data_type<task_manager::srv::AllocatorTask_Response>()
{
  return "task_manager::srv::AllocatorTask_Response";
}

template<>
inline const char * name<task_manager::srv::AllocatorTask_Response>()
{
  return "task_manager/srv/AllocatorTask_Response";
}

template<>
struct has_fixed_size<task_manager::srv::AllocatorTask_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<task_manager::srv::AllocatorTask_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<task_manager::srv::AllocatorTask_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<task_manager::srv::AllocatorTask>()
{
  return "task_manager::srv::AllocatorTask";
}

template<>
inline const char * name<task_manager::srv::AllocatorTask>()
{
  return "task_manager/srv/AllocatorTask";
}

template<>
struct has_fixed_size<task_manager::srv::AllocatorTask>
  : std::integral_constant<
    bool,
    has_fixed_size<task_manager::srv::AllocatorTask_Request>::value &&
    has_fixed_size<task_manager::srv::AllocatorTask_Response>::value
  >
{
};

template<>
struct has_bounded_size<task_manager::srv::AllocatorTask>
  : std::integral_constant<
    bool,
    has_bounded_size<task_manager::srv::AllocatorTask_Request>::value &&
    has_bounded_size<task_manager::srv::AllocatorTask_Response>::value
  >
{
};

template<>
struct is_service<task_manager::srv::AllocatorTask>
  : std::true_type
{
};

template<>
struct is_service_request<task_manager::srv::AllocatorTask_Request>
  : std::true_type
{
};

template<>
struct is_service_response<task_manager::srv::AllocatorTask_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // TASK_MANAGER__SRV__DETAIL__ALLOCATOR_TASK__TRAITS_HPP_
