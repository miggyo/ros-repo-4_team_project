// generated from rosidl_generator_c/resource/idl.h.em
// with input from task_manager:srv/AllocatorTask.idl
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__SRV__ALLOCATOR_TASK_H_
#define TASK_MANAGER__SRV__ALLOCATOR_TASK_H_

#include "task_manager/srv/detail/allocator_task__struct.h"
#include "task_manager/srv/detail/allocator_task__functions.h"
#include "task_manager/srv/detail/allocator_task__type_support.h"

#endif  // TASK_MANAGER__SRV__ALLOCATOR_TASK_H_
