// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK_MANAGER__SRV__ALLOCATOR_TASK_HPP_
#define TASK_MANAGER__SRV__ALLOCATOR_TASK_HPP_

#include "task_manager/srv/detail/allocator_task__struct.hpp"
#include "task_manager/srv/detail/allocator_task__builder.hpp"
#include "task_manager/srv/detail/allocator_task__traits.hpp"

#endif  // TASK_MANAGER__SRV__ALLOCATOR_TASK_HPP_
