from task_manager.srv._allocator_task import AllocatorTask  # noqa: F401
from task_manager.srv._generate_order import GenerateOrder  # noqa: F401
