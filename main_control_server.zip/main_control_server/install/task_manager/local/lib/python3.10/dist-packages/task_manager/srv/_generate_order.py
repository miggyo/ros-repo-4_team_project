# generated from rosidl_generator_py/resource/_idl.py.em
# with input from task_manager:srv/GenerateOrder.idl
# generated code does not contain a copyright notice


# Import statements for member types

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_GenerateOrder_Request(type):
    """Metaclass of message 'GenerateOrder_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('task_manager')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'task_manager.srv.GenerateOrder_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__generate_order__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__generate_order__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__generate_order__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__generate_order__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__generate_order__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class GenerateOrder_Request(metaclass=Metaclass_GenerateOrder_Request):
    """Message class 'GenerateOrder_Request'."""

    __slots__ = [
    ]

    _fields_and_field_types = {
    }

    SLOT_TYPES = (
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)


# Import statements for member types

# Member 'quantities'
import array  # noqa: E402, I100

import builtins  # noqa: E402, I100

# already imported above
# import rosidl_parser.definition


class Metaclass_GenerateOrder_Response(type):
    """Metaclass of message 'GenerateOrder_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('task_manager')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'task_manager.srv.GenerateOrder_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__generate_order__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__generate_order__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__generate_order__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__generate_order__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__generate_order__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class GenerateOrder_Response(metaclass=Metaclass_GenerateOrder_Response):
    """Message class 'GenerateOrder_Response'."""

    __slots__ = [
        '_item_ids',
        '_names',
        '_quantities',
        '_warehouses',
        '_racks',
        '_cells',
        '_statuses',
    ]

    _fields_and_field_types = {
        'item_ids': 'sequence<string>',
        'names': 'sequence<string>',
        'quantities': 'sequence<int32>',
        'warehouses': 'sequence<string>',
        'racks': 'sequence<string>',
        'cells': 'sequence<string>',
        'statuses': 'sequence<string>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.UnboundedString()),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.UnboundedString()),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('int32')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.UnboundedString()),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.UnboundedString()),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.UnboundedString()),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.UnboundedString()),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.item_ids = kwargs.get('item_ids', [])
        self.names = kwargs.get('names', [])
        self.quantities = array.array('i', kwargs.get('quantities', []))
        self.warehouses = kwargs.get('warehouses', [])
        self.racks = kwargs.get('racks', [])
        self.cells = kwargs.get('cells', [])
        self.statuses = kwargs.get('statuses', [])

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.item_ids != other.item_ids:
            return False
        if self.names != other.names:
            return False
        if self.quantities != other.quantities:
            return False
        if self.warehouses != other.warehouses:
            return False
        if self.racks != other.racks:
            return False
        if self.cells != other.cells:
            return False
        if self.statuses != other.statuses:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def item_ids(self):
        """Message field 'item_ids'."""
        return self._item_ids

    @item_ids.setter
    def item_ids(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, str) for v in value) and
                 True), \
                "The 'item_ids' field must be a set or sequence and each value of type 'str'"
        self._item_ids = value

    @builtins.property
    def names(self):
        """Message field 'names'."""
        return self._names

    @names.setter
    def names(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, str) for v in value) and
                 True), \
                "The 'names' field must be a set or sequence and each value of type 'str'"
        self._names = value

    @builtins.property
    def quantities(self):
        """Message field 'quantities'."""
        return self._quantities

    @quantities.setter
    def quantities(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'i', \
                "The 'quantities' array.array() must have the type code of 'i'"
            self._quantities = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, int) for v in value) and
                 all(val >= -2147483648 and val < 2147483648 for val in value)), \
                "The 'quantities' field must be a set or sequence and each value of type 'int' and each integer in [-2147483648, 2147483647]"
        self._quantities = array.array('i', value)

    @builtins.property
    def warehouses(self):
        """Message field 'warehouses'."""
        return self._warehouses

    @warehouses.setter
    def warehouses(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, str) for v in value) and
                 True), \
                "The 'warehouses' field must be a set or sequence and each value of type 'str'"
        self._warehouses = value

    @builtins.property
    def racks(self):
        """Message field 'racks'."""
        return self._racks

    @racks.setter
    def racks(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, str) for v in value) and
                 True), \
                "The 'racks' field must be a set or sequence and each value of type 'str'"
        self._racks = value

    @builtins.property
    def cells(self):
        """Message field 'cells'."""
        return self._cells

    @cells.setter
    def cells(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, str) for v in value) and
                 True), \
                "The 'cells' field must be a set or sequence and each value of type 'str'"
        self._cells = value

    @builtins.property
    def statuses(self):
        """Message field 'statuses'."""
        return self._statuses

    @statuses.setter
    def statuses(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, str) for v in value) and
                 True), \
                "The 'statuses' field must be a set or sequence and each value of type 'str'"
        self._statuses = value


class Metaclass_GenerateOrder(type):
    """Metaclass of service 'GenerateOrder'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('task_manager')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'task_manager.srv.GenerateOrder')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__generate_order

            from task_manager.srv import _generate_order
            if _generate_order.Metaclass_GenerateOrder_Request._TYPE_SUPPORT is None:
                _generate_order.Metaclass_GenerateOrder_Request.__import_type_support__()
            if _generate_order.Metaclass_GenerateOrder_Response._TYPE_SUPPORT is None:
                _generate_order.Metaclass_GenerateOrder_Response.__import_type_support__()


class GenerateOrder(metaclass=Metaclass_GenerateOrder):
    from task_manager.srv._generate_order import GenerateOrder_Request as Request
    from task_manager.srv._generate_order import GenerateOrder_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
