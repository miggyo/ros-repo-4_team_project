# generated from ament_package/template/environment_hook/pythonpath.sh.in

ament_prepend_unique_value PYTHONPATH "$AMENT_CURRENT_PREFIX/local/lib/python3.10/dist-packages"
