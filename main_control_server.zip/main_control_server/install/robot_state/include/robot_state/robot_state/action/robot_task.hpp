// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__ACTION__ROBOT_TASK_HPP_
#define ROBOT_STATE__ACTION__ROBOT_TASK_HPP_

#include "robot_state/action/detail/robot_task__struct.hpp"
#include "robot_state/action/detail/robot_task__builder.hpp"
#include "robot_state/action/detail/robot_task__traits.hpp"

#endif  // ROBOT_STATE__ACTION__ROBOT_TASK_HPP_
