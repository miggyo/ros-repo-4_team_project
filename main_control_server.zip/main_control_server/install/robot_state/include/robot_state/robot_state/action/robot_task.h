// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_state:action/RobotTask.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__ACTION__ROBOT_TASK_H_
#define ROBOT_STATE__ACTION__ROBOT_TASK_H_

#include "robot_state/action/detail/robot_task__struct.h"
#include "robot_state/action/detail/robot_task__functions.h"
#include "robot_state/action/detail/robot_task__type_support.h"

#endif  // ROBOT_STATE__ACTION__ROBOT_TASK_H_
