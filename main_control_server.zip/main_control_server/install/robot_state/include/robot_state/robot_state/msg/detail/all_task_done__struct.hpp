// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_state:msg/AllTaskDone.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__DETAIL__ALL_TASK_DONE__STRUCT_HPP_
#define ROBOT_STATE__MSG__DETAIL__ALL_TASK_DONE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_state__msg__AllTaskDone __attribute__((deprecated))
#else
# define DEPRECATED__robot_state__msg__AllTaskDone __declspec(deprecated)
#endif

namespace robot_state
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AllTaskDone_
{
  using Type = AllTaskDone_<ContainerAllocator>;

  explicit AllTaskDone_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->robot_name = "";
      this->result_msg = "";
      this->task_assignment = "";
    }
  }

  explicit AllTaskDone_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : robot_name(_alloc),
    result_msg(_alloc),
    task_assignment(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->robot_name = "";
      this->result_msg = "";
      this->task_assignment = "";
    }
  }

  // field types and members
  using _robot_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _robot_name_type robot_name;
  using _result_msg_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _result_msg_type result_msg;
  using _task_assignment_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _task_assignment_type task_assignment;

  // setters for named parameter idiom
  Type & set__robot_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->robot_name = _arg;
    return *this;
  }
  Type & set__result_msg(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->result_msg = _arg;
    return *this;
  }
  Type & set__task_assignment(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->task_assignment = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_state::msg::AllTaskDone_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_state::msg::AllTaskDone_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_state::msg::AllTaskDone_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_state::msg::AllTaskDone_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_state::msg::AllTaskDone_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_state::msg::AllTaskDone_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_state::msg::AllTaskDone_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_state::msg::AllTaskDone_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_state::msg::AllTaskDone_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_state::msg::AllTaskDone_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_state__msg__AllTaskDone
    std::shared_ptr<robot_state::msg::AllTaskDone_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_state__msg__AllTaskDone
    std::shared_ptr<robot_state::msg::AllTaskDone_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AllTaskDone_ & other) const
  {
    if (this->robot_name != other.robot_name) {
      return false;
    }
    if (this->result_msg != other.result_msg) {
      return false;
    }
    if (this->task_assignment != other.task_assignment) {
      return false;
    }
    return true;
  }
  bool operator!=(const AllTaskDone_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AllTaskDone_

// alias to use template instance with default allocator
using AllTaskDone =
  robot_state::msg::AllTaskDone_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_state

#endif  // ROBOT_STATE__MSG__DETAIL__ALL_TASK_DONE__STRUCT_HPP_
