// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_state:msg/TaskProgressUpdate.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__TASK_PROGRESS_UPDATE_H_
#define ROBOT_STATE__MSG__TASK_PROGRESS_UPDATE_H_

#include "robot_state/msg/detail/task_progress_update__struct.h"
#include "robot_state/msg/detail/task_progress_update__functions.h"
#include "robot_state/msg/detail/task_progress_update__type_support.h"

#endif  // ROBOT_STATE__MSG__TASK_PROGRESS_UPDATE_H_
