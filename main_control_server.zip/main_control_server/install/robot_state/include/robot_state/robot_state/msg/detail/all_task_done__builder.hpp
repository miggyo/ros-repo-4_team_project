// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_state:msg/AllTaskDone.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__DETAIL__ALL_TASK_DONE__BUILDER_HPP_
#define ROBOT_STATE__MSG__DETAIL__ALL_TASK_DONE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_state/msg/detail/all_task_done__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_state
{

namespace msg
{

namespace builder
{

class Init_AllTaskDone_task_assignment
{
public:
  explicit Init_AllTaskDone_task_assignment(::robot_state::msg::AllTaskDone & msg)
  : msg_(msg)
  {}
  ::robot_state::msg::AllTaskDone task_assignment(::robot_state::msg::AllTaskDone::_task_assignment_type arg)
  {
    msg_.task_assignment = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_state::msg::AllTaskDone msg_;
};

class Init_AllTaskDone_result_msg
{
public:
  explicit Init_AllTaskDone_result_msg(::robot_state::msg::AllTaskDone & msg)
  : msg_(msg)
  {}
  Init_AllTaskDone_task_assignment result_msg(::robot_state::msg::AllTaskDone::_result_msg_type arg)
  {
    msg_.result_msg = std::move(arg);
    return Init_AllTaskDone_task_assignment(msg_);
  }

private:
  ::robot_state::msg::AllTaskDone msg_;
};

class Init_AllTaskDone_robot_name
{
public:
  Init_AllTaskDone_robot_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AllTaskDone_result_msg robot_name(::robot_state::msg::AllTaskDone::_robot_name_type arg)
  {
    msg_.robot_name = std::move(arg);
    return Init_AllTaskDone_result_msg(msg_);
  }

private:
  ::robot_state::msg::AllTaskDone msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_state::msg::AllTaskDone>()
{
  return robot_state::msg::builder::Init_AllTaskDone_robot_name();
}

}  // namespace robot_state

#endif  // ROBOT_STATE__MSG__DETAIL__ALL_TASK_DONE__BUILDER_HPP_
