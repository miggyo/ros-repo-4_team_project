// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_state:msg/TaskProgressUpdate.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__BUILDER_HPP_
#define ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_state/msg/detail/task_progress_update__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_state
{

namespace msg
{

namespace builder
{

class Init_TaskProgressUpdate_task_complete
{
public:
  explicit Init_TaskProgressUpdate_task_complete(::robot_state::msg::TaskProgressUpdate & msg)
  : msg_(msg)
  {}
  ::robot_state::msg::TaskProgressUpdate task_complete(::robot_state::msg::TaskProgressUpdate::_task_complete_type arg)
  {
    msg_.task_complete = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_state::msg::TaskProgressUpdate msg_;
};

class Init_TaskProgressUpdate_current_rack
{
public:
  explicit Init_TaskProgressUpdate_current_rack(::robot_state::msg::TaskProgressUpdate & msg)
  : msg_(msg)
  {}
  Init_TaskProgressUpdate_task_complete current_rack(::robot_state::msg::TaskProgressUpdate::_current_rack_type arg)
  {
    msg_.current_rack = std::move(arg);
    return Init_TaskProgressUpdate_task_complete(msg_);
  }

private:
  ::robot_state::msg::TaskProgressUpdate msg_;
};

class Init_TaskProgressUpdate_robot_name
{
public:
  Init_TaskProgressUpdate_robot_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TaskProgressUpdate_current_rack robot_name(::robot_state::msg::TaskProgressUpdate::_robot_name_type arg)
  {
    msg_.robot_name = std::move(arg);
    return Init_TaskProgressUpdate_current_rack(msg_);
  }

private:
  ::robot_state::msg::TaskProgressUpdate msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_state::msg::TaskProgressUpdate>()
{
  return robot_state::msg::builder::Init_TaskProgressUpdate_robot_name();
}

}  // namespace robot_state

#endif  // ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__BUILDER_HPP_
