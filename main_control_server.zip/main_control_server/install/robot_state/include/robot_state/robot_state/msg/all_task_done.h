// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_state:msg/AllTaskDone.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__ALL_TASK_DONE_H_
#define ROBOT_STATE__MSG__ALL_TASK_DONE_H_

#include "robot_state/msg/detail/all_task_done__struct.h"
#include "robot_state/msg/detail/all_task_done__functions.h"
#include "robot_state/msg/detail/all_task_done__type_support.h"

#endif  // ROBOT_STATE__MSG__ALL_TASK_DONE_H_
