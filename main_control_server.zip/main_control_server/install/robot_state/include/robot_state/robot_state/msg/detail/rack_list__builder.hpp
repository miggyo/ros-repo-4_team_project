// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_state:msg/RackList.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__DETAIL__RACK_LIST__BUILDER_HPP_
#define ROBOT_STATE__MSG__DETAIL__RACK_LIST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_state/msg/detail/rack_list__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_state
{

namespace msg
{

namespace builder
{

class Init_RackList_scenario
{
public:
  explicit Init_RackList_scenario(::robot_state::msg::RackList & msg)
  : msg_(msg)
  {}
  ::robot_state::msg::RackList scenario(::robot_state::msg::RackList::_scenario_type arg)
  {
    msg_.scenario = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_state::msg::RackList msg_;
};

class Init_RackList_rack_list
{
public:
  Init_RackList_rack_list()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RackList_scenario rack_list(::robot_state::msg::RackList::_rack_list_type arg)
  {
    msg_.rack_list = std::move(arg);
    return Init_RackList_scenario(msg_);
  }

private:
  ::robot_state::msg::RackList msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_state::msg::RackList>()
{
  return robot_state::msg::builder::Init_RackList_rack_list();
}

}  // namespace robot_state

#endif  // ROBOT_STATE__MSG__DETAIL__RACK_LIST__BUILDER_HPP_
