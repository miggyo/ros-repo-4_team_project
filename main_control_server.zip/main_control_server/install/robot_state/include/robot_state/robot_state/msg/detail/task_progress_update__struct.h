// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_state:msg/TaskProgressUpdate.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__STRUCT_H_
#define ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'robot_name'
// Member 'current_rack'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/TaskProgressUpdate in the package robot_state.
typedef struct robot_state__msg__TaskProgressUpdate
{
  /// "Robo1"
  rosidl_runtime_c__String robot_name;
  /// "R_A1"
  rosidl_runtime_c__String current_rack;
  /// true
  bool task_complete;
} robot_state__msg__TaskProgressUpdate;

// Struct for a sequence of robot_state__msg__TaskProgressUpdate.
typedef struct robot_state__msg__TaskProgressUpdate__Sequence
{
  robot_state__msg__TaskProgressUpdate * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_state__msg__TaskProgressUpdate__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__STRUCT_H_
