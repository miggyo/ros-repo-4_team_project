// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_state:msg/RackList.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__RACK_LIST_H_
#define ROBOT_STATE__MSG__RACK_LIST_H_

#include "robot_state/msg/detail/rack_list__struct.h"
#include "robot_state/msg/detail/rack_list__functions.h"
#include "robot_state/msg/detail/rack_list__type_support.h"

#endif  // ROBOT_STATE__MSG__RACK_LIST_H_
