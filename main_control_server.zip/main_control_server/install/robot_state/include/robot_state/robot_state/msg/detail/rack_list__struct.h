// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_state:msg/RackList.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__DETAIL__RACK_LIST__STRUCT_H_
#define ROBOT_STATE__MSG__DETAIL__RACK_LIST__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'rack_list'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/RackList in the package robot_state.
typedef struct robot_state__msg__RackList
{
  rosidl_runtime_c__String__Sequence rack_list;
  bool scenario;
} robot_state__msg__RackList;

// Struct for a sequence of robot_state__msg__RackList.
typedef struct robot_state__msg__RackList__Sequence
{
  robot_state__msg__RackList * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_state__msg__RackList__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_STATE__MSG__DETAIL__RACK_LIST__STRUCT_H_
