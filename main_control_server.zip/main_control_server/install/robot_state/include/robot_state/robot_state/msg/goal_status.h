// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_state:msg/GoalStatus.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__GOAL_STATUS_H_
#define ROBOT_STATE__MSG__GOAL_STATUS_H_

#include "robot_state/msg/detail/goal_status__struct.h"
#include "robot_state/msg/detail/goal_status__functions.h"
#include "robot_state/msg/detail/goal_status__type_support.h"

#endif  // ROBOT_STATE__MSG__GOAL_STATUS_H_
