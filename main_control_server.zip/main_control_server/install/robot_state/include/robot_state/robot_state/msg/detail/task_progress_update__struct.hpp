// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_state:msg/TaskProgressUpdate.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__STRUCT_HPP_
#define ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_state__msg__TaskProgressUpdate __attribute__((deprecated))
#else
# define DEPRECATED__robot_state__msg__TaskProgressUpdate __declspec(deprecated)
#endif

namespace robot_state
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct TaskProgressUpdate_
{
  using Type = TaskProgressUpdate_<ContainerAllocator>;

  explicit TaskProgressUpdate_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->robot_name = "";
      this->current_rack = "";
      this->task_complete = false;
    }
  }

  explicit TaskProgressUpdate_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : robot_name(_alloc),
    current_rack(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->robot_name = "";
      this->current_rack = "";
      this->task_complete = false;
    }
  }

  // field types and members
  using _robot_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _robot_name_type robot_name;
  using _current_rack_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _current_rack_type current_rack;
  using _task_complete_type =
    bool;
  _task_complete_type task_complete;

  // setters for named parameter idiom
  Type & set__robot_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->robot_name = _arg;
    return *this;
  }
  Type & set__current_rack(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->current_rack = _arg;
    return *this;
  }
  Type & set__task_complete(
    const bool & _arg)
  {
    this->task_complete = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_state::msg::TaskProgressUpdate_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_state::msg::TaskProgressUpdate_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_state::msg::TaskProgressUpdate_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_state::msg::TaskProgressUpdate_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_state::msg::TaskProgressUpdate_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_state::msg::TaskProgressUpdate_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_state::msg::TaskProgressUpdate_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_state::msg::TaskProgressUpdate_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_state::msg::TaskProgressUpdate_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_state::msg::TaskProgressUpdate_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_state__msg__TaskProgressUpdate
    std::shared_ptr<robot_state::msg::TaskProgressUpdate_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_state__msg__TaskProgressUpdate
    std::shared_ptr<robot_state::msg::TaskProgressUpdate_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TaskProgressUpdate_ & other) const
  {
    if (this->robot_name != other.robot_name) {
      return false;
    }
    if (this->current_rack != other.current_rack) {
      return false;
    }
    if (this->task_complete != other.task_complete) {
      return false;
    }
    return true;
  }
  bool operator!=(const TaskProgressUpdate_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TaskProgressUpdate_

// alias to use template instance with default allocator
using TaskProgressUpdate =
  robot_state::msg::TaskProgressUpdate_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_state

#endif  // ROBOT_STATE__MSG__DETAIL__TASK_PROGRESS_UPDATE__STRUCT_HPP_
