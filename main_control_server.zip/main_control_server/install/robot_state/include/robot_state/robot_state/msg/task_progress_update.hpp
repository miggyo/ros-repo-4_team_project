// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__TASK_PROGRESS_UPDATE_HPP_
#define ROBOT_STATE__MSG__TASK_PROGRESS_UPDATE_HPP_

#include "robot_state/msg/detail/task_progress_update__struct.hpp"
#include "robot_state/msg/detail/task_progress_update__builder.hpp"
#include "robot_state/msg/detail/task_progress_update__traits.hpp"

#endif  // ROBOT_STATE__MSG__TASK_PROGRESS_UPDATE_HPP_
