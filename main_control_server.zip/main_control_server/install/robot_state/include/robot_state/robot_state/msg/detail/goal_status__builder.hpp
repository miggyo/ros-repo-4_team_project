// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_state:msg/GoalStatus.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__MSG__DETAIL__GOAL_STATUS__BUILDER_HPP_
#define ROBOT_STATE__MSG__DETAIL__GOAL_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_state/msg/detail/goal_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_state
{

namespace msg
{

namespace builder
{

class Init_GoalStatus_status
{
public:
  explicit Init_GoalStatus_status(::robot_state::msg::GoalStatus & msg)
  : msg_(msg)
  {}
  ::robot_state::msg::GoalStatus status(::robot_state::msg::GoalStatus::_status_type arg)
  {
    msg_.status = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_state::msg::GoalStatus msg_;
};

class Init_GoalStatus_current_rack
{
public:
  Init_GoalStatus_current_rack()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GoalStatus_status current_rack(::robot_state::msg::GoalStatus::_current_rack_type arg)
  {
    msg_.current_rack = std::move(arg);
    return Init_GoalStatus_status(msg_);
  }

private:
  ::robot_state::msg::GoalStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_state::msg::GoalStatus>()
{
  return robot_state::msg::builder::Init_GoalStatus_current_rack();
}

}  // namespace robot_state

#endif  // ROBOT_STATE__MSG__DETAIL__GOAL_STATUS__BUILDER_HPP_
