// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from robot_state:msg/TaskProgressUpdate.idl
// generated code does not contain a copyright notice
#include "robot_state/msg/detail/task_progress_update__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `robot_name`
// Member `current_rack`
#include "rosidl_runtime_c/string_functions.h"

bool
robot_state__msg__TaskProgressUpdate__init(robot_state__msg__TaskProgressUpdate * msg)
{
  if (!msg) {
    return false;
  }
  // robot_name
  if (!rosidl_runtime_c__String__init(&msg->robot_name)) {
    robot_state__msg__TaskProgressUpdate__fini(msg);
    return false;
  }
  // current_rack
  if (!rosidl_runtime_c__String__init(&msg->current_rack)) {
    robot_state__msg__TaskProgressUpdate__fini(msg);
    return false;
  }
  // task_complete
  return true;
}

void
robot_state__msg__TaskProgressUpdate__fini(robot_state__msg__TaskProgressUpdate * msg)
{
  if (!msg) {
    return;
  }
  // robot_name
  rosidl_runtime_c__String__fini(&msg->robot_name);
  // current_rack
  rosidl_runtime_c__String__fini(&msg->current_rack);
  // task_complete
}

bool
robot_state__msg__TaskProgressUpdate__are_equal(const robot_state__msg__TaskProgressUpdate * lhs, const robot_state__msg__TaskProgressUpdate * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // robot_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->robot_name), &(rhs->robot_name)))
  {
    return false;
  }
  // current_rack
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->current_rack), &(rhs->current_rack)))
  {
    return false;
  }
  // task_complete
  if (lhs->task_complete != rhs->task_complete) {
    return false;
  }
  return true;
}

bool
robot_state__msg__TaskProgressUpdate__copy(
  const robot_state__msg__TaskProgressUpdate * input,
  robot_state__msg__TaskProgressUpdate * output)
{
  if (!input || !output) {
    return false;
  }
  // robot_name
  if (!rosidl_runtime_c__String__copy(
      &(input->robot_name), &(output->robot_name)))
  {
    return false;
  }
  // current_rack
  if (!rosidl_runtime_c__String__copy(
      &(input->current_rack), &(output->current_rack)))
  {
    return false;
  }
  // task_complete
  output->task_complete = input->task_complete;
  return true;
}

robot_state__msg__TaskProgressUpdate *
robot_state__msg__TaskProgressUpdate__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  robot_state__msg__TaskProgressUpdate * msg = (robot_state__msg__TaskProgressUpdate *)allocator.allocate(sizeof(robot_state__msg__TaskProgressUpdate), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(robot_state__msg__TaskProgressUpdate));
  bool success = robot_state__msg__TaskProgressUpdate__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
robot_state__msg__TaskProgressUpdate__destroy(robot_state__msg__TaskProgressUpdate * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    robot_state__msg__TaskProgressUpdate__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
robot_state__msg__TaskProgressUpdate__Sequence__init(robot_state__msg__TaskProgressUpdate__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  robot_state__msg__TaskProgressUpdate * data = NULL;

  if (size) {
    data = (robot_state__msg__TaskProgressUpdate *)allocator.zero_allocate(size, sizeof(robot_state__msg__TaskProgressUpdate), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = robot_state__msg__TaskProgressUpdate__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        robot_state__msg__TaskProgressUpdate__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
robot_state__msg__TaskProgressUpdate__Sequence__fini(robot_state__msg__TaskProgressUpdate__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      robot_state__msg__TaskProgressUpdate__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

robot_state__msg__TaskProgressUpdate__Sequence *
robot_state__msg__TaskProgressUpdate__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  robot_state__msg__TaskProgressUpdate__Sequence * array = (robot_state__msg__TaskProgressUpdate__Sequence *)allocator.allocate(sizeof(robot_state__msg__TaskProgressUpdate__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = robot_state__msg__TaskProgressUpdate__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
robot_state__msg__TaskProgressUpdate__Sequence__destroy(robot_state__msg__TaskProgressUpdate__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    robot_state__msg__TaskProgressUpdate__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
robot_state__msg__TaskProgressUpdate__Sequence__are_equal(const robot_state__msg__TaskProgressUpdate__Sequence * lhs, const robot_state__msg__TaskProgressUpdate__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!robot_state__msg__TaskProgressUpdate__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
robot_state__msg__TaskProgressUpdate__Sequence__copy(
  const robot_state__msg__TaskProgressUpdate__Sequence * input,
  robot_state__msg__TaskProgressUpdate__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(robot_state__msg__TaskProgressUpdate);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    robot_state__msg__TaskProgressUpdate * data =
      (robot_state__msg__TaskProgressUpdate *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!robot_state__msg__TaskProgressUpdate__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          robot_state__msg__TaskProgressUpdate__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!robot_state__msg__TaskProgressUpdate__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
