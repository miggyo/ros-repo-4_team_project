// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_state:srv/UpdateDB.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__SRV__UPDATE_DB_H_
#define ROBOT_STATE__SRV__UPDATE_DB_H_

#include "robot_state/srv/detail/update_db__struct.h"
#include "robot_state/srv/detail/update_db__functions.h"
#include "robot_state/srv/detail/update_db__type_support.h"

#endif  // ROBOT_STATE__SRV__UPDATE_DB_H_
