// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_STATE__SRV__UPDATE_DB_HPP_
#define ROBOT_STATE__SRV__UPDATE_DB_HPP_

#include "robot_state/srv/detail/update_db__struct.hpp"
#include "robot_state/srv/detail/update_db__builder.hpp"
#include "robot_state/srv/detail/update_db__traits.hpp"

#endif  // ROBOT_STATE__SRV__UPDATE_DB_HPP_
